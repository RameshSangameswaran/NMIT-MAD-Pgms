package com.example.multitreading;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.multitreading.databinding.FragmentFirstBinding;

public class FirstFragment extends Fragment {

    private FragmentFirstBinding binding;

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = FragmentFirstBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    private int uiClickCount = 0;

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.buttonFirst.setOnClickListener(v ->
                NavHostFragment.findNavController(FirstFragment.this)
                        .navigate(R.id.action_FirstFragment_to_SecondFragment)
        );

        binding.buttonStartThread.setOnClickListener(v -> startBackgroundTask());

        binding.buttonUiTask.setOnClickListener(v -> {
            uiClickCount++;
            binding.textviewFirst.setText(getString(R.string.ui_clicks, uiClickCount));
        });
    }

    private void startBackgroundTask() {
        binding.buttonStartThread.setEnabled(false);
        binding.textviewStatus.setText(R.string.status_running_initial); // Need to add this or use generic
        binding.progressBar.setProgress(0);

        new Thread(() -> {
            for (int i = 1; i <= 10; i++) {
                final int progress = i * 10;
                try {
                    Thread.sleep(1000); // Simulate long task (1 second)
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                // Update UI from background thread using runOnUiThread
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        binding.progressBar.setProgress(progress);
                        binding.textviewStatus.setText(getString(R.string.status_running, progress));
                    });
                }
            }

            // Task finished, update UI one last time
            if (getActivity() != null) {
                getActivity().runOnUiThread(() -> {
                    binding.textviewStatus.setText(R.string.status_finished);
                    binding.buttonStartThread.setEnabled(true);
                });
            }
        }).start();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}