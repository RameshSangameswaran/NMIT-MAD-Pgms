package com.example.multitreading;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import com.example.multitreading.databinding.ActivityMainBinding;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private int clickCount = 0;
    
    // Executor for background tasks
    private final ExecutorService executorService = Executors.newSingleThreadExecutor();
    // Handler to post updates to the main thread
    private final Handler mainThreadHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Setup View Binding
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // 1. Background Task Button
        binding.btnStartThread.setOnClickListener(v -> startBackgroundTask());

        // 2. UI Counter Button (to prove the UI is not frozen)
        binding.btnUiClick.setOnClickListener(v -> {
            clickCount++;
            binding.tvCounter.setText("UI Clicks: " + clickCount);
        });
    }

    private void startBackgroundTask() {
        // Prepare UI
        binding.btnStartThread.setEnabled(false);
        binding.tvStatus.setText("Status: Running...");
        binding.progressBar.setProgress(0);

        // Execute task in background thread
        executorService.execute(() -> {
            for (int i = 1; i <= 10; i++) {
                int progress = i * 10;
                
                try {
                    // Simulate heavy work
                    Thread.sleep(1000); 
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                // Update UI on Main Thread
                mainThreadHandler.post(() -> {
                    binding.progressBar.setProgress(progress);
                    binding.tvStatus.setText("Status: Working... (" + progress + "%)");
                });
            }

            // Task complete
            mainThreadHandler.post(() -> {
                binding.tvStatus.setText("Status: Finished!");
                binding.btnStartThread.setEnabled(true);
            });
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Shutdown executor to prevent memory leaks
        executorService.shutdown();
    }
}
