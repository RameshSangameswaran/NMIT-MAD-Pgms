package com.example.alert_receiving_a_msg;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.widget.Toast;

public class MessageReceiver extends BroadcastReceiver {

    public interface MessageListener {
        void onMessageReceived(String message);
    }

    private static MessageListener mListener;

    public static void bindListener(MessageListener listener) {
        mListener = listener;
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        Bundle data = intent.getExtras();
        if (data != null) {
            Object[] pdus = (Object[]) data.get("pdus");
            String format = data.getString("format");
            if (pdus != null) {
                for (Object pdu : pdus) {
                    SmsMessage smsMessage = SmsMessage.createFromPdu((byte[]) pdu, format);
                    String messageBody = smsMessage.getMessageBody();
                    
                    if (mListener != null) {
                        mListener.onMessageReceived(messageBody);
                    } else {
                        Toast.makeText(context, "Message: " + messageBody, Toast.LENGTH_LONG).show();
                    }
                }
            }
        }
    }
}
