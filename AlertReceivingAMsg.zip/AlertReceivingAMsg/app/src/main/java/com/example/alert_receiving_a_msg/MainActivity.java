package com.example.alert_receiving_a_msg;

import android.Manifest;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.alert_receiving_a_msg.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity implements MessageReceiver.MessageListener {

    private ActivityMainBinding binding;
    private MessageReceiver messageReceiver;
    private static final int SMS_PERMISSION_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);

        ViewCompat.setOnApplyWindowInsetsListener(binding.main, (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        checkPermissions();

        messageReceiver = new MessageReceiver();

        // Show a "Welcome" alert as requested
        new AlertDialog.Builder(this)
                .setTitle("App Started")
                .setMessage("The application is now listening for incoming messages. Use the form below to send a message.")
                .setPositiveButton("OK", null)
                .show();

        binding.btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendSms();
            }
        });
    }

    private void checkPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            
            ActivityCompat.requestPermissions(this, 
                new String[]{Manifest.permission.RECEIVE_SMS, Manifest.permission.SEND_SMS}, 
                SMS_PERMISSION_CODE);
        }
    }

    private void sendSms() {
        String phone = binding.editPhone.getText().toString();
        String message = binding.editMessage.getText().toString();

        if (phone.isEmpty() || message.isEmpty()) {
            Toast.makeText(this, "Please enter both phone and message", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phone, null, message, null, null);
            Toast.makeText(this, "SMS Sent Successfully", Toast.LENGTH_SHORT).show();
            binding.editMessage.setText("");
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS: " + e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        MessageReceiver.bindListener(this);
        IntentFilter filter = new IntentFilter("android.provider.Telephony.SMS_RECEIVED");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(messageReceiver, filter, RECEIVER_EXPORTED);
        } else {
            registerReceiver(messageReceiver, filter);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(messageReceiver);
        MessageReceiver.bindListener(null);
    }

    @Override
    public void onMessageReceived(String message) {
        new AlertDialog.Builder(this)
                .setTitle("Incoming Message Alert")
                .setMessage(message)
                .setPositiveButton("Dismiss", null)
                .show();
    }
}