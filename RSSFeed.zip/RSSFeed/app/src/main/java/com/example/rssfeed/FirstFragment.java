package com.example.rssfeed;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.rssfeed.databinding.FragmentFirstBinding;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class FirstFragment extends Fragment {

    private FragmentFirstBinding binding;
    private RssAdapter adapter;
    private final List<RssItem> rssItems = new ArrayList<>();
    private final ExecutorService executorService = Executors.newSingleThreadExecutor();

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        binding = FragmentFirstBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.rssRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new RssAdapter(rssItems, item -> {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(item.getLink()));
            startActivity(intent);
        });
        binding.rssRecyclerView.setAdapter(adapter);

        MainViewModel viewModel = new ViewModelProvider(requireActivity()).get(MainViewModel.class);
        viewModel.getRefreshTrigger().observe(getViewLifecycleOwner(), refresh -> {
            if (refresh) {
                fetchRssFeed("https://www.nasa.gov/rss/dyn/breaking_news.rss");
                viewModel.resetRefreshTrigger();
            }
        });

        fetchRssFeed("https://www.nasa.gov/rss/dyn/breaking_news.rss");
    }

    private void fetchRssFeed(String urlString) {
        binding.progressBar.setVisibility(View.VISIBLE);
        executorService.execute(() -> {
            try {
                URL url = new URL(urlString);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                InputStream inputStream = connection.getInputStream();

                RssParser parser = new RssParser();
                List<RssItem> items = parser.parse(inputStream);

                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        rssItems.clear();
                        rssItems.addAll(items);
                        adapter.notifyDataSetChanged();
                        binding.progressBar.setVisibility(View.GONE);
                    });
                }
            } catch (Exception e) {
                Log.e("FirstFragment", "Error fetching RSS feed", e);
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        binding.progressBar.setVisibility(View.GONE);
                    });
                }
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
