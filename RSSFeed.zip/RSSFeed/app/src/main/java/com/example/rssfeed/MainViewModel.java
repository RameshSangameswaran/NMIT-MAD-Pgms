package com.example.rssfeed;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.List;

public class MainViewModel extends ViewModel {
    private final MutableLiveData<Boolean> refreshTrigger = new MutableLiveData<>(false);

    public void triggerRefresh() {
        refreshTrigger.setValue(true);
    }

    public LiveData<Boolean> getRefreshTrigger() {
        return refreshTrigger;
    }

    public void resetRefreshTrigger() {
        refreshTrigger.setValue(false);
    }
}
