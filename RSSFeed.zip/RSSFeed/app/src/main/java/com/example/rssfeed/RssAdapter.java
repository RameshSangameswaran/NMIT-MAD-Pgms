package com.example.rssfeed;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class RssAdapter extends RecyclerView.Adapter<RssAdapter.ViewHolder> {

    private final List<RssItem> rssItems;
    private final OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(RssItem item);
    }

    public RssAdapter(List<RssItem> rssItems, OnItemClickListener listener) {
        this.rssItems = rssItems;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.rss_item_layout, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        RssItem item = rssItems.get(position);
        holder.title.setText(item.getTitle());
        holder.description.setText(item.getDescription());
        holder.link.setText(item.getLink());
        holder.itemView.setOnClickListener(v -> listener.onItemClick(item));
    }

    @Override
    public int getItemCount() {
        return rssItems.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView title, description, link;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.rss_title);
            description = itemView.findViewById(R.id.rss_description);
            link = itemView.findViewById(R.id.rss_link);
        }
    }
}
